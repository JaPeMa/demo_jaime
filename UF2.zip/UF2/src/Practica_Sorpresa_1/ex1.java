package Practica_Sorpresa_1;
import java.util.Arrays;
import java.util.Scanner;
public class ex1 {
	
	
	//INTRODUCIR LAS NOTAS DECIMALES CON .    POR EJEMPLO: 8.6
	
	
	//lectores
	static int leerint() { //lector de int
		Scanner lector=new Scanner(System.in);
		return lector.nextInt();
	}
	static double leerdouble() { //lector de double
		Scanner lector=new Scanner(System.in);
		return lector.nextDouble();
	}
	public static String leerString() { //lector de Strings
		Scanner lector=new Scanner(System.in);
		return lector.nextLine();
	}
	
	
	//main
	public static void main(String[] args) {
		String opcion;
		double notas[]=new double[40];
		for (int i=0;i<notas.length;i++) { //inicio el array con -1 para saber hasta d�nde ha llegado el usuario
			notas[i]=-1;
		}
		do {
			opcion=menu();
			Switch(opcion, notas);
		}while(!opcion.equals("FI"));
	}
	
	
	//m�todos
	public static String menu() { //muestra el men� y lee la opci�n
		System.out.println("Benvingut al gestor de notes\r\n" + 
				"----------------------------\r\n" + 
				"[RT] Registrar notes.\r\n" + 
				"[MJ] Consultar nota mitjana.\r\n" + 
				"[HT] Histograma de notes.\r\n" + 
				"[FI] Sortir.\r\n");
		System.out.print("Opci�: ");
		return leerString();
	}
	public static void Switch(String opcio, double[] array) { //m�todo que har� de switch y llamar� a los m�todos principales
		switch(opcio) {
		case "RT":
			RT(array);
			break;
		case "MJ":
			System.out.println("La nota mitjana �s de "+MJ(array)+".");
			break;
		case "HT":
			HT(array);
			break;
		case "FI":
			System.out.println("Adeu!");
			break;
		default:
			System.out.println("Aquesta no es una opci� v�lida!");
			break;
		
		}
	}
	public static int buscar_pos(double[] array) { //devolver� el primer �ndice en el que el usuario no ha introducido nada
		int i=0;
		while(i<40 && array[i]!=-1) {
			i++;
		}
		return i;
	}
	public static double[] RT(double[] array) { //Rellenar� el Array "notas" con los n�meros introducidos por el usuario convirtiendolos de String a double
		System.out.println("Introdueix els n�meros separats per espais, -1 per sortir");
		String cadena=leerString();
		int pos1=0;
		for(int i=0;i<cadena.length();i++) {
			if(cadena.charAt(i)==' ') {
				if(Double.parseDouble(cadena.substring(pos1, i))!=-1 //comprueba si el n�mero resultante NO es -1
						&& (Double.parseDouble(cadena.substring(pos1, i))<=10 && Double.parseDouble(cadena.substring(pos1, i))>=0)) { //Y si est� entre 0 y 10 
					array[buscar_pos(array)]=Double.parseDouble(cadena.substring(pos1, i)); //si se cumplen ambas condiciones lo mete en el array
					pos1=i+1;
				}
				
			}
		}
		return array;
	}
	public static double MJ(double[] array) { //calcular� la media(no tiene mucho misterio)
		double res=0;
		for(int i=0;i<buscar_pos(array);i++) {
			res+=array[i];
		}
		
		return res/(buscar_pos(array));
	}
	public static void histo(int num) { // imprimir� el histograma
		for(int i=0;i<num;i++) {
			System.out.print("*");
		}
	}
	public static void HT(double[] array) { //Buscar� cuantas notas hay que cumplan las condiciones que piden (susp�s, aprovat...) y llamar� a un m�todo que imprimir� el histograma
		int suspes=0,aprovat=0,notable=0,excelent=0;
		for (int i=0;i<buscar_pos(array);i++) {
			if(array[i]<5)
				suspes++;
			if(array[i]>=5 && array[i]<6.5)
				aprovat++;
			if(array[i]>=6.5 && array[i]<=8.5)
				notable++;
			if(array[i]>8.5)
				excelent++;
		}
		System.out.print("\nSusp�s: ");histo(suspes);
		System.out.print("\nAprovat: ");histo(aprovat);
		System.out.print("\nNotable: ");histo(notable);
		System.out.print("\nExcelent: ");histo(excelent);
		System.out.println();
	}
}

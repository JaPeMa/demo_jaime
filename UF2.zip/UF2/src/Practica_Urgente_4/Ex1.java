package Practica_Urgente_4;

import java.util.Arrays;
import java.util.Scanner;

public class Ex1 {
	static int leerint() { //lector de int
		Scanner lector=new Scanner(System.in);
		return lector.nextInt();
	}
	static double leerDouble() { //lector de Double
		Scanner lector=new Scanner(System.in);
		return lector.nextDouble();
	}
	public static void main(String[] args) {
		int selec;
		int[] array=new int[10];
		for(int i=0;i<array.length;i++) {
			array[i]=(int)(Math.random()*10);
		}
		//Llegados a este punto tengo un array de 10 posiciones con n�meros aleatorios en base 10 
		do{
			System.out.println("Qu� ejercicio quieres resolver? (5 para salir)");
			selec=leerint();
			switch(selec) {
			case 1:
				System.out.println("Ordenaci�n Burbuja:");
				burbujaRecursivo(array, array.length, false);
				break;
			case 2:
				System.out.println("Ordenaci�n QuickSort:");
				quickSort(array);
				System.out.println(Arrays.toString(array));
				break;
			case 3:
				System.out.println("Introduzca un n�mero para calcular los decimales de pi (8999 como m�ximo)");
				System.out.println(2*pi(leerDouble()));
				break;
			case 4:
				System.out.println("Introduzca 1 para la multiplicaci�n egipcia y 2 para la rusa");
				int selec2=leerint();
				switch (selec2) {
				case 1:
					System.out.println("Introduce los dos n�meros a multiplicar");
					int num1=leerint(),num2=leerint(),elevado=1;
					int[] array1= {num1},array2= {1};
					multiplicacionEgipcia(num1, num2, false, array1, array2, elevado);
					break;
				case 2:
					System.out.println("Introduce los dos n�meros a multiplicar");
					multiplicaci�nRusa(leerint(), leerint(), 0);
					break;
				}
				break;
			}
		}while(selec!=5);
	}
	public static void burbujaRecursivo(int[] array, int len, boolean salir) {
		if(!salir) { //salir es un boolean que le pasamos como false
			salir=true; //una vez dentro del if le cambiamos el valor a true
			for(int i=0;i<len-1;i++) { //bucle que se repetir� desde 0 hasta len-1 (variable que vamos pasando con su valor-1 cada vez que llamamos al m�todo)
				if(array[i]>array[i+1]) { //comprueba que la posici�n actual tiene un valor m�s grande que la siguiente
					int aux=array[i]; //Si se cumple la condici�n anterior intercambia posiciones 
					array[i]=array[i+1];
					array[i+1]=aux;
					salir=false; //Y devuelve el valor false al booleano
				}
			}
			burbujaRecursivo(array, len-1, salir); //se vuelve a llamar a s� mismo con el valor de len-1 para no tener que hacer ifs innecesarios
		}else
			System.out.println(Arrays.toString(array)); //si no entra en el primer if significa que ya est� ordenado as� que imprime el array
	}
	public static void quickSort(int[] array) {
        recursiveQuickSort(array, 0, array.length - 1); //llama al m�todo recursivo d�ndole el primer �ndice del array(0) el �ltimo(array.length-1) y el array en s�
    }
	public static void recursiveQuickSort(int[] array, int startIdx, int endIdx) {
	     
        int idx = partition(array, startIdx, endIdx); //llama al m�todo para encontrar el "pivot"

        //se llama de manera recursiva pasando idx-1 donde estaba el �ltimo �ndice para que salga del if
        if (startIdx < idx - 1) {
            recursiveQuickSort(array, startIdx, idx - 1);
        }

        //se llama de manera recursiva pasando idx donde estaba el primer �ndice para que salga del if
        if (endIdx > idx) {
            recursiveQuickSort(array, idx, endIdx);
        }
    }
	public static int partition(int[] array, int left, int right) {
        int pivot = array[left]; //toma como pivot el primer �ndice

        while (left <= right) {
            //busca el primer n�mero que sea m�s grande que el pivot sumando la posici�n que va comparando (de abajo hacia arriba)
            while (array[left] < pivot) {
                left++;
            }
            //lo mismo que el anterior bucle pero del rev�s (de arriba hacia abajo)
            while (array[right] > pivot) {
                right--;
            }

            // intercambia los valores que ha encontrado antes
            if (left <= right) {
                int tmp = array[left];
                array[left] = array[right];
                array[right] = tmp;

                //suma uno a izquierda y resta uno a derecha
                left++;
                right--;
            }
        }
        return left;
    }
	
	public static double pi(double n) { //Lo he hecho con double ya que con int redondea a 0 
		if(n==1) { //n==1 es el caso base, aqu� acaba la recursividad
			return ((2*n)/((2*n)-1))*((2*n)/((2*n)+1)); //formula de pi
			
		}else {
			return (((2*n)/((2*n)-1))*((2*n)/((2*n)+1)))*pi(n-1); //llamada recursiva: formula de pi*pi(n-1)
		}
	}
	
	public static void multiplicaci�nRusa(int num1, int num2, int res) {
		if(num1==0) { // si num1 ha llegado a 0 se para la recursividad e imprime el resultado
			System.out.println("Resultat: "+res);
		}else {
			System.out.println(num1+"||"+num2); //imprime ambos n�meros separados por "||"
			if(num1%2!=0) //Si num1 es impar se suma num2 actual a res
				res+=num2;
			multiplicaci�nRusa(num1/2,num2*2,res); //se hace la llamada recursiva pasando la mitad de num1, el doble de num2 y el resultado que haya por el momento
		}
	}
	
	public static int sumatori(int[] array) { //M�todo que devuelve la suma de todos los elementos de un array
		int suma=0;
		for(int i=0;i<array.length;i++) {
			suma+=array[i];
		}
		return suma;
	}
	
	public static int[] redimensionar(int[] array){ //m�todo para a�adir una posici�n a un array
		int[] array_aux=new int[array.length+1];
		for(int i=0;i<array.length;i++) {
			array_aux[i]=array[i];
		}
		array=array_aux;
		return array;
	}
	
	public static void multiplicacionEgipcia(int num1, int num2, boolean salir, int[] array1,int[] array2, int elevado) {
		if(!salir) { //cuando se cumpla el caso base la variable salir ser� true y saldr� de este if
			if(num2<sumatori(array2)) //caso base
				salir=true;
			else {
				array1=redimensionar(array1); //a�ado una posici�n al array1
				array1[array1.length-1]=array1[array1.length-2]*2; //y la relleno con el doble del valor de la posici�n anterior
				array2=redimensionar(array2); //a�ado una posici�n al array2
				array2[array2.length-1]=(int)(Math.pow(2,elevado)); //y la relleno con 2^elevado
				elevado++; //incrementamos en 1 el valor de elevado
				multiplicacionEgipcia(num1, num2, salir, array1, array2, elevado); //llamada recursiva
			}
		}
		if(salir) { //S�lo entrar� una vez haya pasado por el caso base
			int array3[]= {array2[array2.length-1]},array3_aux[]= {array2.length-1}, cont=array2.length-2; //declaraci�n de variables
			while(sumatori(array3)!=num2) { //bucle que se repetir� hasta que el sumatorio de los valores de array3 sea igual a num2
				if(sumatori(array3)+array2[cont]<=num2) { //si la suma del valor y el sumatorio no sobrepasa el valor de num2 se a�adir� al array
					array3=redimensionar(array3); //se a�ade una posici�n a array3
					array3_aux=redimensionar(array3_aux); //se a�ade una posici�n a array3_aux
					array3[array3.length-1]=array2[cont]; //se pone el valor de array2 con la posici�n cont en la �ltima posici�n de array3
					array3_aux[array3_aux.length-1]=cont; //se a�ade al array3_aux la posici�n de la cual se ha cogido el valor
				}
				cont--; //el contador que sirve para las posiciones se decrementa en 1
			}
			int res=0; //variable de resultado
			for(int i=0;i<array3_aux.length;i++) {
				res+=array1[array3_aux[i]]; //se suma a la variable resultado el valor de array1 asociado a las posiciones guardadas en array3_aux
			}
			System.out.println(res); //se imprime el resultado
		}
	}
	
	
}

package Practica_6;

import java.util.Arrays;
import java.util.Scanner;

public class dani {

	static Scanner sc;
	
	static final String[] atributos = { "Apellidos", "Nombre", "NIF", "Telefono", "Codigo Usuario", "Esborrat" };

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] valores = { "Rios Perez;Borja;49784161A", "Rios Alego;Jose;49784161B",
				"Fernando Peraz;Alberto;049784161C"};
		String valor = null;
		ordenar(valores);
		ask(valores);
	}

	
		public static void ordenar(String[] array){ //m�todo para a�adir una posici�n a un array
			for(int i=1; i<=array.length; i++) {  
				for(int j=0; j<array.length-i; j++) { 
					if( array[j].substring(0, array[j].indexOf(';')).compareTo( array[j+1].substring(0, array[j+1].indexOf(';')) ) > 0 ) { 
		                    String aux   = array[j]; 
		                    array[j]  = array[j+1]; 
		                    array[j+1]= aux; 
		                }    
		            } 
		        }
		}
	


	static void ask(String[] valores) {
		System.out.println("Deseas visualizar el contenido? Si/No");
		String valor = leerString();
		if (valor.equalsIgnoreCase("Si")) {
			for (int i = 0; i < valores.length; i++) {
				System.out.println(valores[i]);
			}
		}
	}
	
	public static String leerString() {
		sc = new Scanner(System.in);
		return sc.nextLine();
	}
	
	public static int leerint() {
		sc = new Scanner(System.in);
		return sc.nextInt();
	}
}

package Practica_6;

import java.util.Arrays;
import java.util.Scanner;

public class Clientes {

	/**
	 * @author Alexis Mengual
	 * @param Menu
	 *            - Muestra las opciones con las que puede trabajar el usuario.
	 * @param ComprobarOpcion
	 *            - Comprueba que la opcion escogida por el usuario sea correcta
	 * @return num - Devuelve el valor de la opci�n.
	 * @param RecercaClient
	 *            - Recoge el vector principal y la opcion escogida por el usuario y
	 *            le muestra un menu, el cual le preguntara porque valor quiere
	 *            buscar.
	 * @param AlgoritmoBusqueda
	 *            - Aplica el algoritmo para buscar el cliente con la instruccion
	 *            enviada desde RecercaClient
	 * @param PressEnter
	 *            - Esta funcion sirve para que el bucle quede en espera, antes de
	 *            devolver el Menu
	 */

	static Scanner lector;

	static final String[] atributos = { "Apellidos", "Nombre", "NIF", "Telefono", "Codigo Usuario", "Esborrat" };

	public static void main(String[] args) {
		Menu();
	}

	// Menu
	public static void Menu() {
		String[] Clientes = new String[10];
		lector = new Scanner(System.in);
		boolean condicion = false;
		int x = 6;
		while (!condicion) {
			System.out.println("-------------------------------------");
			System.out.print(
					"1.Alta de un cliente.\n2.Visualizacion de un cliente.\n3.Baja de un cliente.\n4.Recuperacion de datos de un cliente.\n5.Ordenaci�n de clientes.\n6.B�squeda de clientes.\n7.Salir\n  Escoge una opcion: ");

			// Opciones
			switch (ComprobarOpcion(x)) {
			case 1:
				System.out.println("-------------------------------------");
				// Nestor Ponce:
				// Variables:

				// Llamada Metodos:
				Clientes = AltaClientes(Clientes);
				PressEnter();
				break;
			case 2:
				System.out.println("-------------------------------------");
				// V�ctor Salas:
				// Variables:

				// Llamada Metodos:
				Visualitzaci�(Clientes);
				break;
			case 3:
				System.out.println("-------------------------------------");
				// Jaime Pena, el mafias:
				// Variables:

				// Llamada Metodos:
				BaixaClient(Clientes);
				break;
			case 4:
				System.out.println("-------------------------------------");
				// Jaime Pena:
				// Variables:

				// Llamada Metodos:
				RecuperacioDades(Clientes);
				break;
			case 5:
				System.out.println("-------------------------------------");
				// Daniel Rios:
				// Variables:
				
				// Llamada Metodos:
				ordenar(Clientes);
				ask(Clientes);
				PressEnter();
				break;
			case 6:
				System.out.println("-------------------------------------");
				System.out.print(
						"1.Buscar por Nombre.\n2.Buscar por Apellidos.\n3.Buscar por DNI.\n4.Buscar por Telefono\n5.Buscar por Codigo de Usuario.\n  Escoge una opcion: ");
				int opcio = leerint();
				RecercaClient(Clientes, opcio);
				PressEnter();
				break;
			case 7:
				System.out.println("-------------------------------------");
				System.out.println("Hasta la proxima!");
				condicion = true;
				lector.close();
				break;
			}
		}
	}

	/**
	 * @author N�stor
	 * @param AltaClientes
	 *            - Pide y agrega los datos de un nuevo cliente en el vector
	 *            principal
	 * @return clienes - Devuelve el vector con los datos de un nuevo cliente
	 * @param VacioString
	 *            - Busca el primer null que encuentre, para guardar la posici�n y
	 *            comenzar a introducir los usuarios a partir de ah�.
	 * @return - Devuelve el valor para identificar la posici�n que tenga el primer
	 *         null
	 * 
	 */
	public static String[] AltaClientes(String[] clientes) {
		if (clientes.length == 100 && clientes[99] != null) {
			System.out.println("No puedes dar de alta m�s clientes");
			return clientes;
		} else {
			System.out.println("Introduce un cliente:");
			int i = 0;
			if (clientes[clientes.length - 1] != null) {
				clientes = Redimensionar(clientes);
			}
			i = VacioString(clientes);
			for (int j = 0; j < 6; j++) {
				if (j < 4 && j > 0) {
					System.out.print("\t" + atributos[j] + ": ");
					clientes[i] += leerString();
					clientes[i] += ';';
				} else if (j == 4) {
					clientes[i] += i + 1;
					clientes[i] += ';';
				} else if (j == 5) {
					clientes[i] += 0;
				} else if (j == 0) {
					System.out.print("\t" + atributos[0] + ": ");
					clientes[i] = leerString();
					clientes[i] += ';';
				}
			}
		}
		return clientes;
	}
	// Comprueba la primera posici�n vac�a del array
	public static int VacioString(String[] clientes) {
		for (int i = 0; i < clientes.length; i++) {
			if (clientes[i] == null) 
				return i;
		}
		return 0;
	}

	/**
	 * @author Victor
	 * @param Redimensionar
	 *            - Amplia a 10 posiciones mas en el vector principal
	 * @return array - Devuelve el vector ampliado
	 */
	public static String[] Redimensionar(String[] array) {
		String[] arrayaux = new String[array.length + 10];
		for (int i = 0; i < array.length; i++) {
			arrayaux[i] = array[i];
		}
		array = arrayaux;
		return array;
	}
	// Pide el c�digo para que el resto de m�todos puedan operar con �l
	public static String pedirCodigo() {
		System.out.println("Con qu� c�digo de usuario quieres operar?");
		return leerString();
	}

	// Encuentra la posici�n de un cliente mediante un c�digo proporcionado por el usuario
	public static int posConCod(String[] array, String cod) {
		String cod_comparar;
		int pos = -1;
		for (int i = 0; i < array.length && pos == -1; i++) {
			cod_comparar = array[i].split(";")[4];
			if (cod_comparar.equals(cod))
				pos = i;
		}
		return pos;
	}
	// Ordena el array por el apellido
	public static void ordenar(String[] array){ 
		for(int i=1; i<=VacioString(array); i++) {  
			for(int j=0; j<VacioString(array)-i; j++) { 
				String a1=array[j].substring(0, array[j].indexOf(';')), a2=array[j+1].substring(0, array[j+1].indexOf(';'));
				if( a1.compareTo(a2) > 0 ) { 
	                    String aux = array[j]; 
	                    array[j]  = array[j+1]; 
	                    array[j+1]= aux; 
	                }    
	            } 
	        }
	}
	//Pregunta si quiere mostrar el array despu�s de ordenar
	static void ask(String[] array) {
		System.out.println("Deseas visualizar el contenido? Si/No");
		String valor = leerString();
		if (valor.equalsIgnoreCase("Si")) {
			for (int i = 0; i < VacioString(array); i++) {
				System.out.println(array[i]);
			}
		}
	}
	
	
	

	// RecercaClient
	public static void RecercaClient(String[] alta, int opcio) {
		int contador = 0;
		int pos = 5;
		switch (opcio) {
		case 1:
			System.out.println("Introduce el nombre que quieres comprobar:");
			String x = leerString();
			int y = 1;
			AlgoritmoBusqueda(alta, pos, contador, x, y);
			break;
		case 2:
			System.out.println("Introduce el apellido que quieres comprobar:");
			x = leerString();
			y = 0;
			AlgoritmoBusqueda(alta, pos, contador, x, y);
			break;
		case 3:
			System.out.println("Introduce el NIF que quieres comprobar:");
			x = leerString();
			y = 2;
			AlgoritmoBusqueda(alta, pos, contador, x, y);
			break;
		case 4:
			System.out.println("Introduce el Telefono que quieres comprobar:");
			x = leerString();
			y = 3;
			AlgoritmoBusqueda(alta, pos, contador, x, y);
			break;
		case 5:
			System.out.println("Introduce el Codigo de Usuario que quieres comprobar:");
			x = leerString();
			y = 4;
			AlgoritmoBusqueda(alta, pos, contador, x, y);
			break;
		}
	}

	// AlgorismoBusqueda:
	public static void AlgoritmoBusqueda(String[] alta, int pos, int contador, String x, int y) {
		for (int i = 0; i < alta.length; i++) {
			String comprobar = alta[i];
			if (comprobar == null) {

			} else {
				String[] parts = comprobar.split(";");
				x = x.toUpperCase();
				parts[y] = parts[y].toUpperCase();
				if (parts[y].contains((CharSequence) x) || parts[y].equalsIgnoreCase(x)) {
					if (parts[pos].equals("0")) {
						System.out.println("El usuario " + parts[pos - 1] + ": " + parts[y] + ", esta dado de alta");
						contador = contador + 1;
					} else if (parts[pos].equals("1")) {
						System.out.println("El usuario " + parts[pos - 1] + ": " + parts[y] + ", esta dado de baja");
						contador = contador + 1;
					} else {
						System.out.println("No encontrado");
					}
				}
			}
		}

		if (contador == 0) {
			System.out.println("No hay ningun usuario con esos parametros");
		}

	}

	// Press Enter to
	public static void PressEnter() {
		System.out.println("Pulsa Enter para continuar");
		try {
			System.in.read();
		} catch (Exception e) {
		}
	}

	// Comprobaci�n opci�n
	public static int ComprobarOpcion(int num) {
		if (lector.hasNextInt()) {
			num = lector.nextInt();
			if (num < 1 || num > 7) {
				System.out.println("Escoge un numero del menu");
				PressEnter();
			}
		} else {
			lector.nextLine();
		}
		return num;
	}
	// Comprovar si est� donat de baixa o no
	public static boolean BajaONo(String[] array, String cod) {
		int pos=posConCod(array, cod);
		if(array[pos].charAt(array[pos].length()-1)=='1') 
			return true;
		else
			return false;
	}

	// Visualitzaci� d'un client
	public static void Visualitzaci�(String[] array) {
		String cod = pedirCodigo();
	   	 if(Integer.parseInt(cod)>VacioString(array)) {
	   		 System.out.println("No existe ning�n usuario con ese c�digo");
	   	 }else if (!BajaONo(array, cod)) {
	   		System.out.println(array[posConCod(array, cod)]);
	   	 } else {
	   		 System.out.println("EL Usuario est� dado de baja");
	   	 }
	   	 System.out.println("Introduce cualquier tecla para continuar");
	   	 leerString();
	}
	// Donar de baixa a un client
	public static void BaixaClient(String[] array) {
		String parte1, parte2, cod;
		do {
			cod=pedirCodigo();
			if(Integer.parseInt(cod)>VacioString(array))
				System.out.println("El c�digo introducido no pertenece a ning�n cliente");
		}while(Integer.parseInt(cod)>VacioString(array));
		int pos=posConCod(array, cod);
		parte1=array[pos].substring(0, array[pos].lastIndexOf(';'));
		parte2=array[pos].substring(array[pos].lastIndexOf(';'), array[pos].length());
		parte2=parte2.replace('0', '1');
		if(parte1.concat(parte2).equals(array[pos])) 
			System.out.println("Este cliente ya est� dado de baja");
		else {
			array[pos]=parte1.concat(parte2);
			System.out.println("El cliente ha sido dado de baja correctamente");
		}
	}
	//Recuperacio de dades
	public static void RecuperacioDades(String[] array) {
		String parte1, parte2, cod;
		do {
			cod=pedirCodigo();
			if(Integer.parseInt(cod)>VacioString(array))
				System.out.println("El c�digo introducido no pertenece a ning�n cliente");
		}while(Integer.parseInt(cod)>VacioString(array));
		int pos=posConCod(array, cod);
		parte1=array[pos].substring(0, array[pos].lastIndexOf(';'));
		parte2=array[pos].substring(array[pos].lastIndexOf(';'), array[pos].length());
		parte2=parte2.replace('1', '0');
		if(parte1.concat(parte2).equals(array[pos])) 
			System.out.println("Este cliente no est� dado de baja");
		else {
			array[pos]=parte1.concat(parte2);
			System.out.println("Los datos del cliente se han recuperado correctamente");
		}
	}

	

	// Lectores:
	public static int leerint() {
		lector = new Scanner(System.in);
		return lector.nextInt();
	}

	public static double leerdouble() {
		lector = new Scanner(System.in);
		return lector.nextDouble();
	}

	public static String leerString() {
		lector = new Scanner(System.in);
		return lector.nextLine();
	}

}

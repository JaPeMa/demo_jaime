package Practica_6;

import java.util.Arrays;
import java.util.Scanner;

public class Parte_Jaime {
	static int leerint() {
		Scanner lector=new Scanner(System.in);
		return lector.nextInt();
	}
	static double leerdouble() {
		Scanner lector=new Scanner(System.in);
		return lector.nextDouble();
	}
	public static String leerString() {
		Scanner lector=new Scanner(System.in);
		return lector.nextLine();
	}
	
	
	public static void main(String[] args) {
		String[] clients= {"Jaime;Pe�a;47955140W;663854595;2;1","Victor;Salas;48065433X;645254896;1;0"};
		System.out.println(BajaONo(clients, pedirCodigo()));
		System.out.println(Arrays.toString(clients));
	}

	
	public static void BaixaClient(String[] array) {
		String parte1, parte2;
		int pos=posConCod(array, pedirCodigo());
		parte1=array[pos].substring(0, array[pos].lastIndexOf(';'));
		parte2=array[pos].substring(array[pos].lastIndexOf(';'), array[pos].length());
		parte2=parte2.replace('0', '1');
		array[pos]=parte1+parte2;
	}
	public static void AltaClient(String[] array) {
		String parte1, parte2;
		int pos=posConCod(array, pedirCodigo());
		parte1=array[pos].substring(0, array[pos].lastIndexOf(';'));
		parte2=array[pos].substring(array[pos].lastIndexOf(';'), array[pos].length());
		parte2=parte2.replace('1', '0');
		array[pos]=parte1+parte2;
	}
	public static boolean BajaONo(String[] array, String cod) {
		int pos=posConCod(array, cod);
		if(array[pos].charAt(array[pos].length()-1)=='1')
			return true;
		else
			return false;
	}
	
	public static int posConCod(String[] array, String cod) {
	String cod_comparar;
		int pos=-1;
		for(int i=0;i<array.length && pos==-1;i++) {
			cod_comparar=array[i].split(";")[4];
			if(cod_comparar.equals(cod)) 
				pos=i;
		}
		return pos;
	}
	
	public static String pedirCodigo() {
		System.out.println("Con qu� c�digo de usuario quieres operar?");
		return leerString();
	}
	
	public static boolean taBien(String[] array,int pos, int dato){
		String[] client=array[pos].split(";"); 
		if (dato==0 || dato==1) {
			for(int i=0;i<client[dato].length();i++) {
				if(!(client[dato].charAt(i)>=65 && client[dato].charAt(i)<=90) || !(client[dato].charAt(i)>=97 && client[dato].charAt(i)<=122) || !(client[dato].charAt(i)==32)) {
					return false;
				}
			}
			return true;
		}else if(dato==2) {
			for(int i=0;i<client[dato].length()-1;i++) {
				if(!(client[dato].charAt(i)>=48 && client[dato].charAt(i)<=57)) {
					return false;
				}
			}
			if(!(client[dato].charAt(client[dato].length()-1)>=65 && client[dato].charAt(client[dato].length()-1)<=90) || !(client[dato].charAt(client[dato].length()-1)>=97 && client[dato].charAt(client[dato].length()-1)<=122)) {
				return false;
			}else
				return true;
		}else {
			for(int i=0;i<client[dato].length();i++) {
				if(!(client[dato].charAt(i)>=48 && client[dato].charAt(i)<=57)) {
					return false;
				}
			}
			return true;
		}
	
	}	
}

package Practica_3;

import java.util.Scanner;
public class PT3_1 {
	//Scanners
	static int leerint() { //lector de int
		Scanner lector=new Scanner(System.in);
		return lector.nextInt();
	}
	//main
    public static void main(String[] args) {
        //variables
        boolean ganaUsuario1 = false, ganaUsuario2 = false;
        int[][] vectorMapaUsuario1 = new int[5][5];
        int filaUsuario1, columnaUsuario1, filaUsuario2, columnaUsuario2;
        int[][] vectorMapaUsuario2 = new int[5][5];
        //entrada
        System.out.println("VAMOS A JUGAR A HUNDIR LA FLOTA (barcos de un solo punto)\n");
        System.out.print("Player 1 Introduce tus coordenadas para colocar tu barco: ");
        filaUsuario1 = leerint();
        columnaUsuario1 = leerint();
        System.out.print("Player 2 Introduce tus coordenadas para colocar tu barco: ");
        filaUsuario2 = leerint();
        columnaUsuario2 = leerint();
        //mapa del usuario 1
        System.out.println("\nMAPA DEL USUARIO 1");
        mapa(vectorMapaUsuario1, columnaUsuario1, filaUsuario1);
        System.out.println("\n");
        //mapa del usuario 2
        System.out.println("MAPA DEL USUARIO 2");
        mapa(vectorMapaUsuario2, columnaUsuario2, filaUsuario2);
        System.out.println();
        quien_gana(juego(ganaUsuario1, ganaUsuario2, columnaUsuario2, filaUsuario2, columnaUsuario1, filaUsuario1));
    }
    public static int[][] mapa(int[][] mapa, int columna, int fila){
    	for (int i = 0; i < mapa.length; i++) {
             System.out.println("");
             for (int j = 0; j < mapa.length; j++) {
                 if (i == columna) {
                     if (j == fila) 
                         mapa[i][j] = 1;
                 } else 
                     mapa[i][j] = 0;
                 System.out.print(mapa[i][j]);
             }
         }
    	return mapa;
    }
    public static boolean juego(boolean ganaUsuario1, boolean ganaUsuario2, int columnaUsuario2, int filaUsuario2, int columnaUsuario1, int filaUsuario1) {
    	int tiraUsuario1Fila, tiraUsuario1Columna, tiraUsuario2Fila, tiraUsuario2Columna;
    	while (!ganaUsuario1 && !ganaUsuario2) {
            System.out.println("\nUsuario 1 introduce tus coordenadas para el disparo: ");
            tiraUsuario1Fila = leerint();
            tiraUsuario1Columna = leerint();
            if (tiraUsuario1Columna == columnaUsuario2 && tiraUsuario1Fila == filaUsuario2) {
                ganaUsuario1 = true;
            } else {
                System.out.println("AGUA!\n");
                System.out.println("Usuario 2 introduce tus coordenadas para el disparo: \n");
                tiraUsuario2Fila = leerint();
                tiraUsuario2Columna = leerint();
                if (tiraUsuario2Columna == columnaUsuario1 && tiraUsuario2Fila == filaUsuario1) 
                    ganaUsuario2 = true;
                else 
                    System.out.println("\nAGUA");
            }
        }
    	return ganaUsuario1;
    }
    public static void quien_gana(boolean ganaUsuario1) {
    	if(ganaUsuario1)
    		System.out.println("�GANA EL USUARIO 1!");
    	else
    		System.out.println("�GANA EL USUARIO 2!");
    }
}
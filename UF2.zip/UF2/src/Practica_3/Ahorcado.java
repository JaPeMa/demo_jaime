package Practica_3;
 
import java.util.Scanner;
 

public class Ahorcado {
	public static String leerString() { //lector de Strings
		Scanner lector=new Scanner(System.in);
		return lector.nextLine();
	}
    public static void main(String[] args) {
        int contador = 0, vidas = 6, aciertos = 0, tama�o;
        String palabra, palabras[] = new String[]{"lapiz", "goma", "libreta", "maestro", "examen", "matematicas"}, opcion=""; 
        char[] respuesta;
        
        palabra = palabra(palabras);
        tama�o = palabra.length();
        respuesta = new char[tama�o];
        respuesta=respuestaBase(tama�o, respuesta);
        resultado(jugar(aciertos, tama�o, vidas, contador, respuesta, opcion, palabra), tama�o, respuesta);
        
    }

    public static char[] respuestaBase(int tama�o, char[] respuesta) {
    	for (int i = 0; i < tama�o; i++) {
            respuesta[i] = 'X';
        }
    	return respuesta;
    }
    
    private static void dibujar(int i) {
        switch (i) {
            case 6:
                System.out.println(" ---------------------");
                for (int j = 0; j < 15; j++) {
                    System.out.println(" |");
 
                }
                System.out.println("__________");
                break;
 
            case 5:
                System.out.println(" ---------------------");
                System.out.println(" |                     |");
                System.out.println(" |                     |");
                System.out.println(" |                  -------");
                System.out.println(" |                 | -  -  |");
                System.out.println(" |                 |   o   |");
                System.out.println(" |                  -------");
                for (int j = 0; j < 10; j++) {
                    System.out.println(" |");
 
                }
                System.out.println("__________");
                break;
 
            case 4:
                System.out.println(" ---------------------");
                System.out.println(" |                     |");
                System.out.println(" |                     |");
                System.out.println(" |                  -------");
                System.out.println(" |                 | -  -  |");
                System.out.println(" |                 |   o   |");
                System.out.println(" |                  -------");
                System.out.println(" |                     |   ");
                System.out.println(" |                     |   ");
                System.out.println(" |                     |   ");
                System.out.println(" |                     |   ");
                System.out.println(" |                     |   ");
                for (int j = 0; j < 5; j++) {
                    System.out.println(" |");
 
                }
                System.out.println("__________");
                break;
 
            case 3:
                System.out.println(" ---------------------");
                System.out.println(" |                     |");
                System.out.println(" |                     |");
                System.out.println(" |                  -------");
                System.out.println(" |                 | -  -  |");
                System.out.println(" |                 |   o   |");
                System.out.println(" |                  -------");
                System.out.println(" |                     |   ");
                System.out.println(" |                   / |   ");
                System.out.println(" |                 /   |   ");
                System.out.println(" |                /    |   ");
                System.out.println(" |                     |   ");
                for (int j = 0; j < 5; j++) {
                    System.out.println(" |");
 
                }
                System.out.println("__________");
                break;
 
            case 2:
                System.out.println(" ---------------------");
                System.out.println(" |                     |");
                System.out.println(" |                     |");
                System.out.println(" |                  -------");
                System.out.println(" |                 | -  -  |");
                System.out.println(" |                 |   o   |");
                System.out.println(" |                  -------");
                System.out.println(" |                     |   ");
                System.out.println(" |                   / | \\ ");
                System.out.println(" |                  /  |   \\ ");
                System.out.println(" |                 /   |     \\ ");
                System.out.println(" |                     |   ");
                for (int j = 0; j < 5; j++) {
                    System.out.println(" |");
 
                }
                System.out.println("__________");
                break;
 
            case 1:
                System.out.println(" ---------------------");
                System.out.println(" |                     |");
                System.out.println(" |                     |");
                System.out.println(" |                  -------");
                System.out.println(" |                 | -  -  |");
                System.out.println(" |                 |   o   |");
                System.out.println(" |                  -------");
                System.out.println(" |                     |   ");
                System.out.println(" |                   / | \\ ");
                System.out.println(" |                  /  |   \\ ");
                System.out.println(" |                 /   |     \\ ");
                System.out.println(" |                     |   ");
                System.out.println(" |                    /  ");
                System.out.println(" |                   /      ");
                System.out.println(" |                  /       ");
                for (int j = 0; j < 2; j++) {
                    System.out.println(" |");
 
                }
                System.out.println("__________");
                break;
 
            case 0:
               System.out.println(" ---------------------");
                System.out.println(" |                     |");
                System.out.println(" |                     |");
                System.out.println(" |                  -------");
                System.out.println(" |                 | X  X  |");
                System.out.println(" |                 |   o   |");
                System.out.println(" |                  -------");
                System.out.println(" |                     |   ");
                System.out.println(" |                   / | \\ ");
                System.out.println(" |                  /  |   \\ ");
                System.out.println(" |                 /   |     \\ ");
                System.out.println(" |                     |   ");
                System.out.println(" |                    / \\");
                System.out.println(" |                   /   \\  ");
                System.out.println(" |                  /     \\ ");
                for (int j = 0; j < 2; j++) {
                    System.out.println(" |");
 
                }
                System.out.println("__________");
                System.out.println("GAME OVER");
                break;
        }
    }
    public static int jugar(int aciertos, int tama�o, int vidas, int contador, char[] respuesta, String opcion, String palabra) {
	    while (aciertos != tama�o && vidas != 0) {
	        System.out.println("=========AHORCADO :)==========          VIDAS="+vidas +" Aciertos= "+aciertos);
	        dibujar(vidas);
	        System.out.println("");
	        for (int i = 0; i < tama�o; i++) {
	
	            System.out.print("__" + respuesta[i] + "___  ");
	        }
	        System.out.println("\nIngresa una letra: ");
	        opcion = leerString();
	        if (palabra.contains(opcion)) {
	            for (int i = 0; i < tama�o; i++) {
	                if (palabra.charAt(i) == opcion.charAt(0)) {
	                    respuesta[i] = opcion.charAt(0);
	                    contador++;
	                }
	            }
	
	            aciertos = aciertos + contador;
	        } else {
	            vidas--;
	        }
	
	        contador = 0;
	    }
	    return vidas;
    }
    public static String palabra(String[] palabras) {
    	return palabras[(int)(Math.random()*6)];
    }
    public static void resultado(int vidas, int tama�o, char[] respuesta) {
    	if(vidas==0){
            dibujar(vidas);
        }else
        {
            System.out.println("");
            for (int i = 0; i < tama�o; i++) {
 
                System.out.print("__" + respuesta[i] + "___  ");
            }
            System.out.println("YOU WIN :)");
        }
    }
}
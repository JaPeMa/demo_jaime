package Practica_Urgente_2;

import java.util.Arrays;
import java.util.Scanner;

public class Ex1 {
	//lectores
	static int leerint() { //lector de int
		Scanner lector=new Scanner(System.in);
		return lector.nextInt();
	}
	static double leerdouble() { //lector de double
		Scanner lector=new Scanner(System.in);
		return lector.nextDouble();
	}
	public static String leerString() { //lector de Strings
		Scanner lector=new Scanner(System.in);
		return lector.nextLine();
	}
	
	
	//Main
	public static void main(String[] args) {
		int opcio=0;
		String dades[][]=new String[10][4];
		Switch(opcio,dades);
		
	}
	public static int menu() { //muestra el men� y lee la opci�n
		System.out.println("----------------------------\r\n" + 
				"1. Inscriure participants\r\n" + 
				"2. Mostrar llistat de dades\r\n" + 
				"3. Mostrar llistat per marques\r\n" + 
				"4. Sortir.\r\n" +
				"----------------------------\r\n");
		System.out.print("Si us plau, introdueixi una opci�: ");
		return leerint();
	}
	public static void Switch(int opcio, String[][] dades) { //Funcion que hace el bucle que contiene el switch
		do{
			opcio=menu();
			switch(opcio) {
			case 1:
				op1(dades);
				break;
			case 2:
				op2(dades);
				break;
			case 3:
				op3(dades);
				break;
			case 4:
				System.out.println("Adeu!");
				break;
			default:
				System.out.println("Aquesta no es una opci� valida, torni a provar");
				break;
			}
		}while(opcio!=4);
	}
	public static int buscar_pos(String[][] dades) { //Devuelve el primer �ndice con valor null   por ejemplo: dades[4][3]="6.4"  dades[5][0]=null   devuelve 5
		int i, h;
		boolean salir=false;
		for(i=0;i<dades.length && !salir;i++) {
			for(h=0;h<dades[i].length && !salir;h++) {
				if(dades[i][h]==null) 
					salir=true;
			}
		}
		return i-1;
	}
	public static String[][] op1(String[][] dades){ //introduce en la matriz "dades" el nombre, la mejor marca del 2002, del 2001 y del 2000 consecutivamente
		System.out.print("Nom del participant>>>");
		dades[buscar_pos(dades)][0]=leerString();
		System.out.print("Millor marca del 2002>>>");
		dades[buscar_pos(dades)][1]=leerString();
		System.out.print("Millor marca del 2001>>>");
		dades[buscar_pos(dades)][2]=leerString();
		System.out.print("Millor marca del 2000>>>");
		dades[buscar_pos(dades)][3]=leerString();
		return dades;
	}
	public static void op2(String[][] dades) { //Muestra por pantalla los datos de los participantes que se han introducido hasta ahora
		for(int i=0;i<buscar_pos(dades);i++) {
			System.out.println("Participant amb dorsal "+(i+1)+":\n"+
							"Nom: "+dades[i][0]+"\n"+
							"Millor marca del 2002: "+dades[i][1]+"\n"+
							"Millor marca del 2002: "+dades[i][2]+"\n"+
							"Millor marca del 2002: "+dades[i][3]+"\n");
		}
	}
	public static void op3(String[][] dades) { //rellena una matriz de dos filas con, en la fila de arriba, las marcas convertidas de String a double, y abajo el �ndice que ten�an en un principio
		double marcas[][]=new double[2][buscar_pos(dades)];
		for(int i=0;i<buscar_pos(dades);i++) {
			marcas[0][i]=Double.parseDouble(dades[i][1]);
			marcas[1][i]=i;
		}
		for(int i=marcas[0].length-1;i>0;i--) { //ordena la fila de arriba (la que contiene las marcas) y mantiene en la posici�n de "abajo" el �ndice inicial de cada marca
			for(int h=0;h<i;h++) {
				if(marcas[0][h]<marcas[0][h+1]) {
					double aux=marcas[0][h];
					marcas[0][h]=marcas[0][h+1];
					marcas[0][h+1]=aux;
					aux=marcas[1][h];
					marcas[1][h]=marcas[1][h+1];
					marcas[1][h+1]=aux;
				}
			}
		}
		for(int i=0;i<marcas[1].length;i++) { //Muestra el nombre del participante que est� relacionado a la marca en orden descendente
			System.out.println(dades[(int)(marcas[1][i])][0]);
		}
	}
}

package Practica_1;

import java.util.Scanner;

public class PT1 {
	public static void main(String[] args) {
		String p="palabra";
		System.out.println(p.lastIndexOf('.'));
	}	
	
	static int leerint() {
		Scanner lector=new Scanner(System.in);
		return lector.nextInt();
	}
	static double leerdouble() {
		Scanner lector=new Scanner(System.in);
		return lector.nextDouble();
	}
	public static String leerString() {
		Scanner lector=new Scanner(System.in);
		return lector.nextLine();
	}
	
	
	public static double ex1(double num1, double num2, double num3) {
		double min=num1;
		if(num2<min) 
			min=num2;
		if(num3<min)
			min=num3;
		return min;
	}
	public static double ex2(double num1, double num2, double num3) {
		return (num1+num2+num3)/3;
	}
	public static String ex3(String palabra) {
		String mitad="";
		if(palabra.length()%2==0) {
			mitad=mitad+palabra.charAt((palabra.length()/2)-1)+palabra.charAt(palabra.length()/2);
		}else
			mitad=mitad+palabra.charAt(palabra.length()/2);
		return mitad;
	}
	public static int ex4(String palabra) {
		int cont=0;
		for(int i=0;i<palabra.length();i++) {
			char letra=palabra.charAt(i);
			if (letra=='a' || letra=='e' || letra=='i' || letra=='o' || letra=='u')
				cont++;
		}
		return cont;
	}
	public static int ex5(String frase) {
		return (frase.split(" ").length);
	}
	public static int ex6(int num) {
		int sum=0;
		while(num>0) {
			sum+=(num%10);
			num/=10;
		}
		return sum;
	}
	public static void ex7() {
		for(int i=1;i<=50;i++) {
			if(i%10==0)
				System.out.println();
			System.out.print((i*(3*i-1))/2+" ");
		}
	}
	public static void ex8(double diners, double interes, int year) {
		interes/=12;
		for(int i=0;i<year;i++) {
			for(int h=0;h<12;h++) {
				diners=diners+((diners/100)*interes);
			}
			System.out.println("Any "+(i+1)+": "+diners);
		}
	}
	public static void ex9(char letra1, char letra2) {
		for(int i=letra1;i<=letra2;i++) {
			System.out.println(letra1);
			letra1+=1;
		}
	}
	public static boolean ex10(int year) {
		if(year%4==0)
			return true;
		else
			return false;
	}
	public static void ex11(String password) {
		boolean incorrect=false;
		int cont=0;
		if(password.length()>10) {
			for(int i=0;i<password.length();i++) {
				if((password.charAt(i)>47 && password.charAt(i)<58) || (password.charAt(i)>64 && password.charAt(i)<91) || (password.charAt(i)>96 && password.charAt(i)<122)) {
					if(password.charAt(i)>47 && password.charAt(i)<58) {
						cont++;
					}
				}
				else
					incorrect=true;
			}
		}else
			incorrect=true;
		
		if(cont<2 || incorrect) 
			System.out.println("Password <"+password+"> is invalid");
		else
			System.out.println("Password <"+password+"> is valid");
	}
	public static void ex12(int dim) {
		int matrix[][]=new int[dim][dim];
		for(int i=0;i<matrix.length;i++) {
			for(int h=0;h<matrix[i].length;h++) {
				matrix[i][h]=(int)(Math.random()*2);
				System.out.print(matrix[i][h]+" ");
			}
			System.out.println();
		}
	}
	public static double ex13(double side1,double side2,double side3) {
		double s=(side1+side2+side3)/2;
		return Math.sqrt(s*(s-side1)*(s-side2)*(s-side3));
	}
	public static double ex14(int sides,double len) {
		return (sides*len*(len/1.45))/2;
	}
	public static boolean primos(int num) {
		boolean primo=true;
		for(int h=num-1;h>1 && primo;h--) {
			if(num%h==0)
				primo=false;
		}
		return primo;
	}
	public static void ex15() {
		for(int i=3;i<=100;i++) {
			int h=i+2;
			if(primos(i) && primos(h)) {
				System.out.println("("+i+", "+h+")");
				i++;
			}
		}
	}
}
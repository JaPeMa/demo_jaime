package Practica_5;

import java.util.Scanner;

public class PT5 {
	static int leerint() { //lector de int
		Scanner lector=new Scanner(System.in);
		return lector.nextInt();
	}
	public static void main(String[] args) {
		String bin="";
		int selec,num1,num2;
		do {
			System.out.println("Selecciona el ejercicio que quieras resolver");
			selec=leerint();
			switch(selec) {
			case 1:
				System.out.println("Introduce dos n�meros");
				System.out.println(ex1(leerint(),leerint()));
				break;
			case 2:
				System.out.println("Introduce dos n�meros");
				System.out.println(ex2(leerint(),leerint()));
				break;
			case 3:
				System.out.println("Introduce un n�mero");
				ex3(leerint());
				System.out.println();
				break;
			case 4:
				System.out.println("Introduce dos n�meros");
				num1=leerint(); num2=leerint();
				System.out.println(ex4(num1,num2,num1));
				break;
			case 5:System.out.println("Introduce dos n�meros");
				num1=leerint(); num2=leerint();
				System.out.println(ex5(num1,num2,num1));
				break;
			case 6:
				System.out.println("Introduce un n�mero");
				System.out.println(reverseString(ex6(leerint(),bin)));
				break;
			case 7:
				System.out.println("Adeu!");
				break;
			default:
				System.out.println("Esa no es una opci�n v�lida");
				break;
			}
		
		}while(selec!=7);
	}
	public static int ex1(int num1, int num2) {
		int resultado=0;
		System.out.print(num1+"x"+num2+"=");
		while(num2>0) {
			if(num2==1)
				System.out.print(num1);
			else
				System.out.print(num1+"+");
			resultado+=num1;
			num2--;
		}
		System.out.print("=");
		return resultado;
	}
	public static int ex2(int num1, int num2) {
		int resultado=1;
		System.out.print(num1+"^"+num2+"=");
		while(num2>0) {
			if(num2==1)
				System.out.print(num1);
			else
				System.out.print(num1+"x");
			resultado*=num1;
			num2--;
		}
		System.out.print("=");
		return resultado;
	}
	public static void ex3(int num1) {
		String bin="";
		while(num1>1) {
			if(num1%2==0)
				bin+='0';
			else
				bin+='1';
			num1/=2;
		}
		System.out.print(num1);
		for(int i=bin.length()-1;i>=0;i--) {
			System.out.print(bin.charAt(i));
		}
	}
	public static int ex4(int num1, int num2, int res) {
		if(num2<=1)
			return num1;
		else
			return res+ex4(num1,num2-1,res);
	}
	public static int ex5(int num1, int num2, int res) {
		if(num2<=1)
			return num1;
		else
			return res*ex5(num1,num2-1,res);
	}
	public static String ex6(int num1, String bin) {
		if(num1==0) {
			return bin+'0';
		}else if(num1==1) {
			return bin+'1';
		}else {
			if(num1%2==0) {
				;
				return ex6(num1/2,bin+'0');
			}else {
				return ex6(num1/2,bin+'1');
			}
		}
	}
	public static String reverseString(String string) {
		String string_inverso="";
		for(int i=string.length()-1;i>=0;i--) {
			string_inverso+=string.charAt(i);
		}
		return string_inverso;
	}
}

package Practica_4;

import java.util.Scanner;

public class PT4_2 {
	static int leerint() { //lector de int
		Scanner lector=new Scanner(System.in);
		return lector.nextInt();
	}
	public static void main(String[] args) {
		System.out.println("Introduce un n�mero");
		System.out.println(vuelta(leerint()));

	}
	public static int vuelta(int num) {
		int num_base=num, aux=num%10;
		if(num<10)
			return num;
		else {
			return aux*(int)Math.pow(10,String.valueOf(num_base).length()-1)+vuelta(num/10);
		}
	}
}
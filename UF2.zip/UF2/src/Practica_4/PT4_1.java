package Practica_4;

import java.util.Scanner;

public class PT4_1 {
	static int leerint() { //lector de int
		Scanner lector=new Scanner(System.in);
		return lector.nextInt();
	}
	public static void main(String[] args) {
		System.out.println("SUMA RECURSIVA");
		int cont=0;
		System.out.println(sumaRecursiva(leerint()));
	}
	public static int sumaRecursiva(int cont) {
		System.out.print("Introduce un n�mero>>>");
		int num=leerint();
		if(cont>1) {
			cont--;
			return num+sumaRecursiva(cont);
		}else
			return num;
	}
}

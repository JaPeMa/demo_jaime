package Practica_4;

import java.util.Scanner;

public class PT4_3 {

	
	static int leerint() { //lector de int
		Scanner lector=new Scanner(System.in);
		return lector.nextInt();
	}
	public static void main(String[] args) {
		System.out.print("Introduce un n�mero (true=positivo, false=negativo)>>>");
		System.out.print(pos(leerint()));
	}
	public static boolean pos(int num) {
		if(num>=0)
			return true;
		else
			return neg(num);
	}
	public static boolean neg(int num) {
		if(num<0)
			return false;
		else
			return pos(num);
	}
}
package Practica_2;
	import java.util.Scanner;
	public class PT2_2{
	    public static Scanner keyboard;
	    public static void main(String[] arguments)	{
	    	System.out.println("Hey");
	        keyboard = new Scanner(System.in);
	        int number1,number2;
	        number1 = readNumber();number2 = readNumber();
	        numberN(number1,number2);      
	    }
		 
	    public static int readNumber(){
	    	Scanner lector=new Scanner(System.in);
	    	return lector.nextInt();
	    }
	    public static void numberN(int num1, int num2){
	    	System.out.println(num1+num2);
	    	System.out.println(num1-num2);
	    	System.out.println(num1*num2);
	    	System.out.println(num1/num2);
	    }

	}
package Practica_2;
	import java.util.Scanner;
	public class PT2_1{
	    public static Scanner keyboard;
	    public static void main(String[] arguments)	{
	        keyboard = new Scanner(System.in);
	        int number;
	        number = readNumber();
	        numberN(number);      
	    }
		 
	    public static int readNumber(){
	    	Scanner lector=new Scanner(System.in);
	    	return lector.nextInt();
	    }
	    public static void numberN(int num){
	    	for (int i = 0; i < num; i++) {
				System.out.println("Module executed");
			}
	    }

	}

package Practica_2;

import java.util.Arrays;
import java.util.Scanner;
public class PT2_3
{
    public static Scanner keyboard;
    public static void main(String[] arguments) {
    	int[] box_numbers=new int[readNumber()];
        int quantity_pair,quantity_odd;
        box_numbers = readNumber(box_numbers);
        quantity_pair=numberN(box_numbers,true);
        quantity_odd=numberN(box_numbers,false);
        System.out.println();
        System.out.println(quantity_pair);
        System.out.println(quantity_odd);
    }
    public static int readNumber() {
    	Scanner lector=new Scanner(System.in);
    	return lector.nextInt();
    }	
    public static int[] readNumber(int[] array){
    	for(int i=0;i<array.length;i++) {
    		array[i]=(int)(Math.random()*1000000);
    	}
    	return array;
    }
    public static int numberN(int[] array, boolean bool){
    	int cont=0;
    	for (int i=0;i<array.length;i++) {
			System.out.print(array[i]+" ");
    		if(array[i]%2==0)
				cont++;
		}
    	if (bool)
    		return cont;
    	else
    		return array.length-cont;
    }
    
}
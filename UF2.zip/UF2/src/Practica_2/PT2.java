package Practica_2;

import java.util.Arrays;
import java.util.Scanner;
public class PT2
{
    public static Scanner keyboard;
    public static void main(String[] arguments)
    {
    	int selec;
        do {
        	System.out.print("Introduce el n�mero del ejercicio que quieras resolver, 4 para salir>>>");
        	selec=readNumber();
        	switch(selec) {
        	case 1:
        		int number;
     	        number = readNumber();
     	        numberN(number); 
        		break;
        	case 2:
        		int number1,number2;
        		number1 = readNumber();number2 = readNumber();
    	        numberN(number1,number2); 
        		break;
        	case 3:
        		int[] box_numbers=new int[readNumber()];
                int quantity_pair,quantity_odd;
                box_numbers = readNumber(box_numbers);
                quantity_pair=numberN(box_numbers,true);
                quantity_odd=numberN(box_numbers,false);
                System.out.println();
                System.out.println(quantity_pair);
                System.out.println(quantity_odd);
        		break;
        	case 4:
        		System.out.println("Adeu!");
        		break;
        	default:
        		System.out.println("No es una selecci�n v�lida");
        		break;
        	}
        }while(selec!=4);
    }
    
    public static int readNumber() {
    	Scanner lector=new Scanner(System.in);
    	return lector.nextInt();
    }
    
    public static int[] readNumber(int[] array)
    {
    	for(int i=0;i<array.length;i++) {
    		array[i]=(int)(Math.random()*1000000);
    	}
    	return array;
    }
    
    public static void numberN(int num){
    	for (int i = 0; i < num; i++) {
			System.out.println("Module executed");
		}
    }
    
    public static void numberN(int num1, int num2){
    	System.out.println(num1+num2);
    	System.out.println(num1-num2);
    	System.out.println(num1*num2);
    	System.out.println(num1/num2);
    }
    
    public static int numberN(int[] array, boolean bool)
    {
    	int cont=0;
    	for (int i=0;i<array.length;i++) {
			System.out.print(array[i]+" ");
    		if(array[i]%2==0)
				cont++;
		}
    	if (bool)
    		return cont;
    	else
    		return array.length-cont;
    }
}
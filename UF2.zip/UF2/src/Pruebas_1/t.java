package Pruebas_1;


import java.awt.*;
import javax.swing.*;
public class t extends JFrame {
	public static void main(String[] args) {
		r ventana=new r();
		ventana.setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	
	
}
class r extends JFrame{
	private JPanel contentPanel;
	public r() {
		contentPanel=new JPanel();
		setVisible(true);
		setBounds(100,100,600,400);
		setTitle("Es Una Prueba");
		n lamina=new n();
		contentPanel.setLayout(null);
		contentPanel.add(lamina);
	}
	
}
class n extends JFrame{
	public void print(Graphics g) {
		super.paintComponents(g);
		g.drawString("ESTO ES UNA PRUEBA", 100, 100);
	}
}
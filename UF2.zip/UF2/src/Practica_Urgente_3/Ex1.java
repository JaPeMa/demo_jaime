package Practica_Urgente_3;

import java.util.Arrays;
import java.util.Scanner;

public class Ex1 {

	//lectores
		static int leerint() { //lector de int
			Scanner lector=new Scanner(System.in);
			return lector.nextInt();
		}
		static double leerdouble() { //lector de double
			Scanner lector=new Scanner(System.in);
			return lector.nextDouble();
		}
		public static String leerString() { //lector de Strings
			Scanner lector=new Scanner(System.in);
			return lector.nextLine();
		}
	public static void main(String[] args) {
		int opcio=0;
		Switch(opcio);

	}
	public static int menu() { //muestra el men� y lee la opci�n
		System.out.println("----------------------------\r\n" + 
				"1. MCD\r\n" + 
				"2. MCM\r\n" + 
				"3. C�lculos b�sicos de 2, 3, 4 o 5 n�meros\r\n" + 
				"4. �rea de Triangle, Rectangle o Quadrat\r\n" +
				"5. Sortir\r\n" +
				"----------------------------\r\n");
		System.out.print("Si us plau, introdueixi una opci�: ");
		return leerint();
	}
	public static void Switch(int opcio) { //Funcion que hace el bucle que contiene el switch
		do{
			opcio=menu();
			switch(opcio) {
			case 1:
				System.out.println(calculComu(leerint(),leerint()));
				break;
			case 2:
				int num1=leerint(), num2=leerint(), mcd=calculComu(num1, num2);
				System.out.println(calculComu(num1, num2, mcd));
				break;
			case 3:
				int[] array=llegirValor();
				if(array.length<2)
					System.out.println("Debes introducir 2 o m�s n�meros");
				else if(array.length==2)
					calculOpBasic(array[array.length-2], array[array.length-1]);
				else if(array.length==3)
					calculOpBasic(array[array.length-3], array[array.length-2], array[array.length-1]);
				else if(array.length==4)
					calculOpBasic(array[array.length-4], array[array.length-3], array[array.length-2], array[array.length-1]);
				else if(array.length>=5)
					calculOpBasic(array[array.length-5], array[array.length-4], array[array.length-3], array[array.length-2], array[array.length-1]);
				break;
			case 4:
				System.out.print("Elige qu� �rea quieres calcular: 1 para Tri�ngulo, 2 para Rect�ngulo y 3 para Cuadrado>>>");
				int ex4=leerint();
				switch (ex4) {
				case 1:
					System.out.println("Has elegido: Tri�ngulo\nIntroduce la longitud de los tres lados");
					System.out.println(calculArea(leerdouble(), leerdouble(), leerdouble()));
					break;
				case 2:
					System.out.println("Has elegido: Rect�ngulo\nIntroduce la longitud del lado corto y el largo");
					System.out.println(calculArea(leerdouble(), leerdouble()));
					break;
				case 3:
					System.out.println("Has elegido: Cuadrado\nIntroduce la longitud de uno de los lados");
					System.out.println(calculArea(leerdouble()));
					break;
				default:
					System.out.println("Esa no es una opci�n v�lida");
					break;
				}
				break;
			case 5:
				System.out.println("Adeu!");
				break;
			default:
				System.out.println("Aquesta no es una opci� valida, torni a provar");
				break;
			}
		}while(opcio!=5);
	}
	public static int calculComu(int num1, int num2) {
		int res=0;
		if(num1<0)
			num1=-num1;
		if(num2<0)
			num2=-num2;
		while(num2!=0) {
			res=num1%num2;
			num1=num2;
			num2=res;
		}
		return num1;
	}
	public static int calculComu(int num1, int num2, int mcd) {
		return (num1*num2)/mcd;
	}
	
	public static int[] llegirValor() {
		String nums=leerString();
		String[] array_str=new String[nums.split(" ").length];
		
		int[] array=new int[nums.split(" ").length];
		array_str=nums.split(" ");
		for(int i=array.length-1;i>=0;i--) {
			array[i]=Integer.parseInt(array_str[i]);
		}
		return array;
	}
	
	
	
	public static void calculOpBasic(int num1, int num2) {
		System.out.println("Suma: "+(num1+num2));
		System.out.println("Resta: "+(num1-num2));
		System.out.println("Multiplicaci�n: "+(num1*num2));
		System.out.println("Divisi�n: "+(num1/num2));
	}
	public static void calculOpBasic(int num1, int num2, int num3) {
		System.out.println("Suma: "+(num1+num2+num3));
		System.out.println("Resta: "+(num1-num2-num3));
		System.out.println("Multiplicaci�n: "+num1*num2*num3);
		System.out.println("Divisi�n: "+(num1/num2)/num3);
	}
	public static void calculOpBasic(int num1, int num2, int num3, int num4) {
		System.out.println("Suma: "+(num1+num2+num3+num4));
		System.out.println("Resta: "+(num1-num2-num3-num4));
		System.out.println("Multiplicaci�n: "+num1*num2*num3*num4);
		System.out.println("Divisi�n: "+(((num1/num2)/num3)/num4));
	}
	public static void calculOpBasic(int num1, int num2, int num3, int num4, int num5) {
		System.out.println("Suma: "+(num1+num2+num3+num4+num5));
		System.out.println("Resta: "+(num1-num2-num3-num4-num5));
		System.out.println("Multiplicaci�n: "+num1*num2*num3*num4*num5);
		System.out.println("Divisi�n: "+(((num1/num2)/num3)/num4)/num5);
	}
	
	public static double calculArea(double side1, double side2, double side3) {
		double s=(side1+side2+side3)/2;
		return Math.sqrt(s*(s-side1)*(s-side2)*(s-side3));
	}
	public static double calculArea(double side1, double side2) {
		return side1*side2;
	}
	public static double calculArea(double side1) {
		return Math.pow(side1, 2);
	}
}
